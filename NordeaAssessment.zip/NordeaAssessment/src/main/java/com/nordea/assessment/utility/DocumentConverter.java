package com.nordea.assessment.utility;

import java.time.LocalDateTime;

import java.time.format.DateTimeFormatter;

import com.nordea.assessment.model.Document;
import com.thoughtworks.xstream.converters.Converter;

import com.thoughtworks.xstream.converters.MarshallingContext;

import com.thoughtworks.xstream.converters.UnmarshallingContext;

import com.thoughtworks.xstream.io.HierarchicalStreamReader;

import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

public class DocumentConverter implements Converter {

	private static final DateTimeFormatter DT_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

	@Override
	public boolean canConvert(Class type) {
		return type.equals(Document.class);

	}

	@Override
	public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
		// Don't do anything

	}

	@Override
	public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
		reader.moveDown();
		Document document = new Document();

		//document.setCstmrCdtTrfInitn(reader.getClass().get);

		//reader.moveUp();

		//reader.moveDown();

		

		return document;

	}

}