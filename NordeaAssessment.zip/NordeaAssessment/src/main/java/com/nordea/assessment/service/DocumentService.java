package com.nordea.assessment.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.nordea.assessment.dao.EndToEndRepo;
import com.nordea.assessment.entity.EndToEnd;
import com.nordea.assessment.model.Document;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DocumentService {

	@Autowired
	EndToEndRepo endToEndRepo;

	public void save(Document document) {
		log.info("Saving EndToEndId to DB started");
		EndToEnd endToEndEntity = new EndToEnd();
		endToEndEntity = new EndToEnd();
		endToEndEntity.setEndToEndId(document.getCstmrCdtTrfInitn().getPmtInf().getCdtTrfTxInf().getPmtId().getEndToEndId());
		endToEndRepo.save(endToEndEntity);
		log.info("Saving EndToEndId to DB started");
	}

	/*
	 * public ItemReader<EndToEnd> databaseItemReader() {
	 * log.info("Reading EndToEndId from DB started"); Map<String, Sort.Direction>
	 * sorts = new HashMap<>(); sorts.put("id", Direction.ASC);
	 * RepositoryItemReader<EndToEnd> databaseReader = new RepositoryItemReader<>();
	 * databaseReader.setRepository(endToEndRepo);
	 * databaseReader.setMethodName("findAll"); databaseReader.setSort(sorts);
	 * return databaseReader; }
	 */
	
	
	public ItemReader<EndToEnd> databaseItemReader() {
		log.info("Reading EndToEndId from DB started");
		Map<String, Sort.Direction> sorts = new HashMap<>();
		sorts.put("id", Direction.ASC);
		RepositoryItemReader<EndToEnd> databaseReader = new RepositoryItemReader<>();
		databaseReader.setRepository(endToEndRepo);
		databaseReader.setMethodName("findAll");
		databaseReader.setSort(sorts);
		return databaseReader;
	}

	@Cacheable(value = "endToEndIdCacheById")
	public Optional<EndToEnd> findEndToEndById(int endToEndId) {
		log.info("Invoking findEndToEndById with endToEndId : "+endToEndId);
		
		Optional<EndToEnd> endToEnd = endToEndRepo.findById(endToEndId);
		return endToEnd;
	}

	@Cacheable(value = "endToEndIdCacheAll")
	public List<EndToEnd> findAllEndToEnd() {
		log.info("Invoking findAllEndToEnd");
		return endToEndRepo.findAll();

	}
}
