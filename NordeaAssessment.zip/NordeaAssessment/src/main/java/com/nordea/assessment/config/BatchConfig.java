package com.nordea.assessment.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.scheduling.annotation.Scheduled;

import com.nordea.assessment.entity.EndToEnd;
import com.nordea.assessment.model.Document;
import com.nordea.assessment.service.DocumentService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableBatchProcessing
class BatchConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private DocumentService documentService;

	
	
	@Autowired private SimpleJobLauncher jobLauncher;
	 
	

	@Value("${nordea.inputfile}")
	private String inputFile;

	@Bean
	public StaxEventItemReader<Document> xmlReader() {
		log.info("Stated reading XML file");
		
		
		
		
		/*
		 * Map<String, Class> aliases = new HashMap<>(); aliases.put("Document",
		 * Document.class); DocumentConverter converter = new DocumentConverter();
		 * XStreamMarshaller ummarshaller = new XStreamMarshaller();
		 * ummarshaller.setAliases(aliases); ummarshaller.setConverters(converter);
		 * StaxEventItemReader<Document> reader = new StaxEventItemReader<>();
		 * reader.setResource(new ClassPathResource("pain.001.valid.xml"));
		 * reader.setFragmentRootElementName("Document");
		 * reader.setUnmarshaller(ummarshaller);
		 */
		
		
		
		
		  StaxEventItemReader<Document> reader = new StaxEventItemReader<Document>();
		  reader.setResource(new ClassPathResource("pain.001.valid.xml"));
		  reader.setFragmentRootElementName("Document");
		  
		  Map<String, Class<?>> aliases = new HashMap<String, Class<?>>();
		  aliases.put("Document", Document.class);
		  
		  XStreamMarshaller xStreamMarshaller = new XStreamMarshaller();
		  xStreamMarshaller.setAliases(aliases);
		  
		   //Jaxb2Marshaller xStreamMarshaller = new Jaxb2Marshaller();
		  
		   //xStreamMarshaller.setClassesToBeBound(Document.class);
		  
		  reader.setUnmarshaller(xStreamMarshaller);
		 

		log.info("Finished reading XML file");

		return reader;
	}

	@Bean
	public ItemWriter<Document> xmlToDbWriter() {
		return items -> {
			items.forEach(document -> documentService.save(document));
			log.info("Finished writing to DB");
		};
	}

	@Bean
	public Step xmmlReaderStep1() {
		log.info("Excuting xmmlReaderStep1");
		return stepBuilderFactory.get("xmmlReaderStep1").<Document, Document>chunk(10).reader(xmlReader())
				.writer(xmlToDbWriter()).build();
	}

	
	@Bean
	ItemReader<EndToEnd> databaseItemReader() {
		log.info("Excuting databaseItemReader");
		return documentService.databaseItemReader();
	}

	
	@Bean
	public ItemWriter<EndToEnd> cacheWriter() {
		return items -> {
			for (EndToEnd endToEnd : items) {
				documentService.findEndToEndById(endToEnd.getId());
			}
		};
	}
	

	@Bean
	public Step cacheStep1() {
		return stepBuilderFactory.get("cacheStep1").<EndToEnd, EndToEnd>chunk(10).reader(databaseItemReader())
				.writer(cacheWriter()) .build();
	}

	
	@Bean
	public Job xmlReaderJob() {
		return jobBuilderFactory.get("xmlReaderJob").incrementer(new RunIdIncrementer()).flow(xmmlReaderStep1()).end()
				.build();

	}
	
	
	@Bean
	public Job cacheJob() {
		return jobBuilderFactory.get("cacheJob").incrementer(new RunIdIncrementer()).flow(cacheStep1()).end().build();

	}

	
	
	@Scheduled(cron = "0 0 12 * * *")
	 
	public void perform() throws Exception {

		log.info("xmlReaderJob Job Started at :" + new Date());
		JobExecution xmlReaderJobExecution = jobLauncher.run(xmlReaderJob(), new JobParameters());

		System.out.println("XmlReader Job finished with status :" + xmlReaderJobExecution.getStatus());
		log.info("xmlReaderJob Job Finished at :" + new Date());
		log.info("xmlReaderJob Job finished with status :" + xmlReaderJobExecution.getStatus());
		log.info("xmlReaderJob Job Started at :" + new Date());

		JobExecution cacheJobexecution = jobLauncher.run(cacheJob(), new JobParameters());

		System.out.println("Cache Job finished with status :" + cacheJobexecution.getStatus());
		log.info("cacheJob Job Finished at :" + new Date());
		log.info("cacheJob Job finished with status :" + cacheJobexecution.getStatus());
	}

	
	
	  @Bean public SimpleJobLauncher jobLauncher(JobRepository jobRepository) {
		  SimpleJobLauncher launcher = new SimpleJobLauncher();
		  launcher.setJobRepository(jobRepository); return launcher; 
	  }
	 
	
	
	
	
	

}
