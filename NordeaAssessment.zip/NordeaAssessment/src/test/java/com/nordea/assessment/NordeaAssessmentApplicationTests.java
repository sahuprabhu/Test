package com.nordea.assessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NordeaAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
